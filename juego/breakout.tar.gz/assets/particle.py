import pygame
import random
import math

class Particle:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        angle = random.uniform(0, 2 * math.pi)
        speed = random.uniform(1, 4)
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed
        self.color = color
        self.lifetime = random.randint(15, 30)

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.lifetime -= 1

    def is_alive(self):
        return self.lifetime > 0

    def draw(self, screen):
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), 2)


def spawn_particles(x, y, color, count=10):
    return [Particle(x, y, color) for _ in range(count)]
