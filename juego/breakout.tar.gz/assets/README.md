# Breakout

A clone of the classic brick-breaker arcade game, written from scratch in Python
with Pygame. Built iteratively as my first complete programming project — starting
from a window with a bouncing ball and growing into a game with levels, power-ups,
and persistent high scores.

## Features

- Object-oriented design: paddle, ball, bricks, particles and power-ups as classes
- Rect-based collision detection; bounce angle depends on where the ball hits the paddle
- State machine: start / playing / paused / level clear / game over / win
- Multiple levels loaded from plain-text files (`levels/levelN.txt`)
- Bricks with 1–3 hit points, particle burst and sound on break
- Power-ups: wide paddle, multi-ball, slow ball, extra life
- Lives system and progressive difficulty (ball speeds up each level)
- High scores saved to `highscores.json`

## Run it

```bash
pip install -r requirements.txt
python main.py
```

Requires Python 3.11+.

## Controls

| Key | Action |
|-----|--------|
| ← → or A / D | Move paddle |
| Space | Start / launch next level |
| P | Pause / resume |
| R | Restart after game over or win |

## Level format

Each `levels/levelN.txt` is a grid of digits. `0` is an empty space; `1`–`3` is a
brick with that many hit points. Levels are auto-detected by number.

```
33333333
22222222
11111111
```

## Project structure

```
breakout/
├── main.py         # game loop and state handling
├── paddle.py       # paddle class and input
├── ball.py         # ball movement and collisions
├── brick.py        # brick class and level loading
├── powerup.py      # power-up spawning and behavior
├── particle.py     # particle effects
├── highscores.py   # load/save high scores
├── levels/         # level layouts as text files
└── assets/         # sound effects
```
