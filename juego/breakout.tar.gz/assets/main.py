import asyncio
import pygame
import os
from paddle import Paddle
from ball import Ball
from brick import load_level, total_levels
from particle import spawn_particles
from powerup import maybe_spawn_powerup
from highscores import load_highscores, save_score

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60

POINTS_PER_HIT = 10
STARTING_LIVES = 3
POWERUP_DURATION_MS = 8000
SLOW_BALL_MULTIPLIER = 0.6
LEVEL_SPEED_STEP = 0.15
TOTAL_LEVELS = total_levels()
ASSETS_DIR = os.path.join(os.path.dirname(__file__), "assets")

def load_sound(filename):
    return pygame.mixer.Sound(os.path.join(ASSETS_DIR, filename))

def speed_factor_for_level(level):
    return 1 + LEVEL_SPEED_STEP * (level - 1)

def start_level(screen_width, screen_height, level):
    paddle = Paddle(screen_width, screen_height)
    factor = speed_factor_for_level(level)
    balls = [Ball(screen_width, screen_height, speed_factor=factor)]
    bricks = load_level(level, screen_width)
    return paddle, balls, bricks

async def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Breakout")
    clock = pygame.time.Clock()
    big_font = pygame.font.SysFont(None, 48)
    small_font = pygame.font.SysFont(None, 30)
    hud_font = pygame.font.SysFont(None, 32)
    powerup_font = pygame.font.SysFont(None, 20)

    sounds = {
        "bounce": load_sound("bounce.wav"),
        "break": load_sound("break.wav"),
        "gameover": load_sound("gameover.wav"),
        "win": load_sound("win.wav"),
        "powerup": load_sound("powerup.wav"),
    }

    level = 1
    paddle, balls, bricks = start_level(SCREEN_WIDTH, SCREEN_HEIGHT, level)
    particles = []
    powerups = []
    active_effects = {}
    score = 0
    lives = STARTING_LIVES
    state = "start"  # "start", "playing", "paused", "level_clear", "game_over", "win"

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and state in ("start", "level_clear"):
                    state = "playing"
                elif event.key == pygame.K_p and state == "playing":
                    state = "paused"
                elif event.key == pygame.K_p and state == "paused":
                    state = "playing"
                elif event.key == pygame.K_r and state in ("game_over", "win"):
                    level = 1
                    paddle, balls, bricks = start_level(SCREEN_WIDTH, SCREEN_HEIGHT, level)
                    particles = []
                    powerups = []
                    active_effects = {}
                    score = 0
                    lives = STARTING_LIVES
                    state = "playing"

        keys = pygame.key.get_pressed()
        if state == "playing":
            paddle.handle_input(keys)

            now = pygame.time.get_ticks()
            if "wide_paddle" in active_effects and now > active_effects["wide_paddle"]:
                paddle.set_wide(False)
                del active_effects["wide_paddle"]
            if "slow_ball" in active_effects and now > active_effects["slow_ball"]:
                del active_effects["slow_ball"]

            speed_multiplier = SLOW_BALL_MULTIPLIER if "slow_ball" in active_effects else 1.0

            fallen_balls = []
            for ball in balls:
                fell, events = ball.update(paddle, speed_multiplier)
                if events:
                    sounds["bounce"].play()
                if fell:
                    fallen_balls.append(ball)
            for ball in fallen_balls:
                balls.remove(ball)

            if not balls:
                lives -= 1
                if lives <= 0:
                    state = "game_over"
                    sounds["gameover"].play()
                    save_score(score)
                else:
                    balls = [Ball(SCREEN_WIDTH, SCREEN_HEIGHT, speed_factor=speed_factor_for_level(level))]

            if state == "playing":
                for ball in balls:
                    ball_rect = ball.get_rect()
                    for brick in bricks:
                        if ball_rect.colliderect(brick.rect):
                            ball.speed_y *= -1
                            destroyed = brick.hit()
                            if destroyed:
                                particles += spawn_particles(brick.rect.centerx, brick.rect.centery, (255, 200, 100))
                                powerup = maybe_spawn_powerup(brick.rect.centerx, brick.rect.centery)
                                if powerup:
                                    powerups.append(powerup)
                                bricks.remove(brick)
                                score += POINTS_PER_HIT
                                sounds["break"].play()
                            break

                if not bricks:
                    if level < TOTAL_LEVELS:
                        level += 1
                        paddle, balls, bricks = start_level(SCREEN_WIDTH, SCREEN_HEIGHT, level)
                        particles = []
                        powerups = []
                        active_effects = {}
                        sounds["win"].play()
                        state = "level_clear"
                    else:
                        state = "win"
                        sounds["win"].play()
                        save_score(score)

                for powerup in powerups[:]:
                    powerup.update()
                    if powerup.rect.colliderect(paddle.rect):
                        powerups.remove(powerup)
                        sounds["powerup"].play()
                        expire = pygame.time.get_ticks() + POWERUP_DURATION_MS
                        if powerup.kind == "wide_paddle":
                            paddle.set_wide(True)
                            active_effects["wide_paddle"] = expire
                        elif powerup.kind == "slow_ball":
                            active_effects["slow_ball"] = expire
                        elif powerup.kind == "extra_life":
                            lives += 1
                        elif powerup.kind == "multi_ball" and balls:
                            base = balls[0]
                            for offset in (-2, 2):
                                clone = Ball(SCREEN_WIDTH, SCREEN_HEIGHT, speed_factor=speed_factor_for_level(level))
                                clone.x, clone.y = base.x, base.y
                                clone.speed_x = base.speed_x + offset
                                clone.speed_y = base.speed_y
                                balls.append(clone)
                    elif powerup.rect.top > SCREEN_HEIGHT:
                        powerups.remove(powerup)

        if state in ("playing", "paused"):
            for particle in particles:
                particle.update()
            particles = [p for p in particles if p.is_alive()]

        screen.fill((0, 0, 0))
        paddle.draw(screen)
        for ball in balls:
            ball.draw(screen)
        for brick in bricks:
            brick.draw(screen)
        for particle in particles:
            particle.draw(screen)
        for powerup in powerups:
            powerup.draw(screen, powerup_font)

        score_text = hud_font.render(f"Puntaje: {score}", True, (255, 255, 255))
        lives_text = hud_font.render(f"Vidas: {lives}", True, (255, 255, 255))
        level_text = hud_font.render(f"Nivel: {level}", True, (255, 255, 255))
        screen.blit(score_text, (10, 10))
        screen.blit(level_text, (SCREEN_WIDTH // 2 - 40, 10))
        screen.blit(lives_text, (SCREEN_WIDTH - 130, 10))

        if state == "start":
            highscores = load_highscores()
            best = highscores[0] if highscores else 0
            title = big_font.render("BREAKOUT", True, (255, 255, 255))
            hint = small_font.render("Presiona ESPACIO para empezar", True, (200, 200, 200))
            best_text = small_font.render(f"Mejor puntaje: {best}", True, (200, 200, 200))
            screen.blit(title, title.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 50)))
            screen.blit(hint, hint.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 10)))
            screen.blit(best_text, best_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 45)))
        elif state == "paused":
            text = big_font.render("PAUSA - Presiona P para continuar", True, (255, 255, 255))
            screen.blit(text, text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)))
        elif state == "level_clear":
            text = big_font.render(f"Nivel {level} - Presiona ESPACIO", True, (255, 255, 255))
            screen.blit(text, text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)))
        elif state == "game_over":
            text = big_font.render("GAME OVER - Presiona R para reiniciar", True, (255, 255, 255))
            screen.blit(text, text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)))
        elif state == "win":
            text = big_font.render("GANASTE - Presiona R para reiniciar", True, (255, 255, 255))
            screen.blit(text, text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)))

        pygame.display.flip()
        clock.tick(FPS)
        # Cede el control al navegador cada frame (necesario para la versión web
        # con pygbag; en escritorio simplemente no hace nada perceptible).
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())
