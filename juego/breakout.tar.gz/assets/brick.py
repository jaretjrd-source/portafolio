import pygame
import os

COLORS_BY_HITS = {
    1: (100, 200, 100),
    2: (230, 230, 100),
    3: (220, 100, 100),
}

LEVELS_DIR = os.path.join(os.path.dirname(__file__), "levels")

class Brick:
    def __init__(self, x, y, width, height, hits):
        self.rect = pygame.Rect(x, y, width, height)
        self.hits = hits

    def hit(self):
        self.hits -= 1
        return self.hits <= 0

    def draw(self, screen):
        color = COLORS_BY_HITS.get(self.hits, (200, 200, 200))
        pygame.draw.rect(screen, color, self.rect)
        pygame.draw.rect(screen, (0, 0, 0), self.rect, 1)


def load_level(level_number, screen_width, padding=6, top_offset=60, brick_height=20):
    path = os.path.join(LEVELS_DIR, f"level{level_number}.txt")
    with open(path) as f:
        rows = [line.strip() for line in f if line.strip()]

    cols = len(rows[0])
    brick_width = (screen_width - padding * (cols + 1)) // cols

    bricks = []
    for row_index, row in enumerate(rows):
        for col_index, char in enumerate(row):
            hits = int(char)
            if hits == 0:
                continue
            x = padding + col_index * (brick_width + padding)
            y = top_offset + row_index * (brick_height + padding)
            bricks.append(Brick(x, y, brick_width, brick_height, hits))
    return bricks


def total_levels():
    count = 0
    while os.path.exists(os.path.join(LEVELS_DIR, f"level{count + 1}.txt")):
        count += 1
    return count
