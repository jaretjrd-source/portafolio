import json
import os

HIGHSCORES_PATH = os.path.join(os.path.dirname(__file__), "highscores.json")
MAX_ENTRIES = 5

def load_highscores():
    if not os.path.exists(HIGHSCORES_PATH):
        return []
    try:
        with open(HIGHSCORES_PATH) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return []

def save_score(score):
    scores = load_highscores()
    scores.append(score)
    scores = sorted(scores, reverse=True)[:MAX_ENTRIES]
    try:
        with open(HIGHSCORES_PATH, "w") as f:
            json.dump(scores, f)
    except OSError:
        # En la versión web el sistema de archivos puede ser de solo lectura;
        # los puntajes simplemente no se guardan entre partidas.
        pass
    return scores
