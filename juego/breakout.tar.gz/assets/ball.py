import pygame
import math

class Ball:
    def __init__(self, screen_width, screen_height, speed_factor=1.0):
        self.radius = 8
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.base_speed = 6 * speed_factor
        self.reset()

    def reset(self):
        self.x = self.screen_width // 2
        self.y = self.screen_height // 2
        self.speed_x = self.base_speed * 0.7
        self.speed_y = -self.base_speed * 0.7

    def update(self, paddle, speed_multiplier=1.0):
        events = []
        self.x += self.speed_x * speed_multiplier
        self.y += self.speed_y * speed_multiplier

        if self.x - self.radius <= 0 or self.x + self.radius >= self.screen_width:
            self.speed_x *= -1
            events.append("wall_bounce")
        if self.y - self.radius <= 0:
            self.speed_y *= -1
            events.append("wall_bounce")

        ball_rect = self.get_rect()
        if ball_rect.colliderect(paddle.rect) and self.speed_y > 0:
            offset = (self.x - paddle.rect.centerx) / (paddle.width / 2)
            offset = max(-1, min(1, offset))
            max_angle = math.radians(60)
            angle = offset * max_angle
            speed = math.hypot(self.speed_x, self.speed_y)
            self.speed_x = speed * math.sin(angle)
            self.speed_y = -abs(speed * math.cos(angle))
            events.append("paddle_bounce")

        fell = self.y - self.radius > self.screen_height
        return fell, events

    def get_rect(self):
        return pygame.Rect(
            self.x - self.radius, self.y - self.radius,
            self.radius * 2, self.radius * 2,
        )

    def draw(self, screen):
        pygame.draw.circle(screen, (255, 255, 255), (int(self.x), int(self.y)), self.radius)
