import pygame

class Paddle:
    def __init__(self, screen_width, screen_height):
        self.normal_width = 100
        self.wide_width = 150
        self.width = self.normal_width
        self.height = 15
        self.speed = 8
        self.screen_width = screen_width
        self.rect = pygame.Rect(
            (screen_width - self.width) // 2,
            screen_height - 40,
            self.width,
            self.height,
        )

    def handle_input(self, keys):
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.rect.x += self.speed

        self.rect.x = max(0, min(self.rect.x, self.screen_width - self.width))

    def set_wide(self, wide):
        center = self.rect.centerx
        self.width = self.wide_width if wide else self.normal_width
        self.rect.width = self.width
        self.rect.centerx = center
        self.rect.x = max(0, min(self.rect.x, self.screen_width - self.width))

    def draw(self, screen):
        pygame.draw.rect(screen, (255, 255, 255), self.rect)
