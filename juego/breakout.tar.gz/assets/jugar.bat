@echo off
call "%USERPROFILE%\miniconda3\Scripts\activate.bat" breakout
cd /d "%~dp0"
python main.py
pause
