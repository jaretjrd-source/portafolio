# Propuesta: Juego Breakout (rompe-bloques) en Pygame

## Por qué este proyecto
Es ideal para vibecoding porque cada iteración se ve/juega al instante, tiene una base simple que crece en complejidad de forma natural, y toca conceptos fundamentales (colisiones, estados, física básica) sin abrumar.

## Stack
- Python 3.11+
- Pygame (`pip install pygame`)
- Sin dependencias extra al inicio — luego opcionalmente `json` para guardar puntajes

## Estructura de archivos sugerida
```
breakout/
├── main.py          # loop principal del juego
├── paddle.py        # clase de la paleta
├── ball.py          # clase de la pelota
├── brick.py         # clase de los bloques
├── powerup.py       # (fase 4) power-ups
├── assets/          # sonidos/imágenes opcionales
└── highscores.json  # (fase 5) puntajes guardados
```

## Fases de desarrollo (cada una es un commit/sesión de vibecoding)

**Fase 1 — Esqueleto jugable** ✅
- [x] Ventana de Pygame, loop principal a 60 FPS
- [x] Paleta que se mueve con flechas/A-D
- [x] Pelota que rebota en paredes y en la paleta
- [x] Condición de "game over" si la pelota cae

**Fase 2 — Bloques y colisiones** ✅
- [x] Grid de bloques con distintos colores/resistencia (1-3 golpes)
- [x] Detección de colisión pelota-bloque
- [x] Contador de puntaje visible en pantalla
- [x] Condición de victoria: todos los bloques destruidos

**Fase 3 — Pulido de juego** ✅
- [x] Ángulo de rebote variable según dónde golpea la pelota en la paleta (más control)
- [x] Efecto de partículas simple al romper un bloque
- [x] Sonidos básicos (rebote, romper bloque, game over)
- [x] Pantallas de inicio / pausa / game over

**Fase 4 — Power-ups** ✅
- [x] Al romper ciertos bloques, cae un power-up: paleta más ancha, pelota múltiple, pelota más lenta, vida extra
- [x] Sistema de vidas (3 intentos antes de game over real)

**Fase 5 — Progresión y persistencia** ✅
- [x] Múltiples niveles (distintos patrones de bloques, quizás cargados desde archivos de texto/JSON)
- [x] Guardar highscores en `highscores.json`
- [x] Aumento de dificultad (velocidad de pelota crece con el nivel)

## Aprendizajes clave por fase
1. Loop de juego, eventos, dibujo en pantalla
2. Programación orientada a objetos, detección de colisiones (rects)
3. Manejo de estados (menús, pausa), assets, timing
4. Composición de comportamientos (power-ups como objetos independientes)
5. Serialización de datos, diseño de niveles como datos externos

## Cómo lo vamos a trabajar
Se construye fase por fase: cada una se prueba jugando y se ajusta sobre la marcha (velocidad, dificultad, "se siente raro el rebote", etc.), que es donde brilla el vibecoding: iteración rápida guiada por cómo se *siente* jugar.
