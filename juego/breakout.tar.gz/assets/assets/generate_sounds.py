import wave
import struct
import math
import os

SAMPLE_RATE = 44100

def generate_tone(filename, freq_start, freq_end=None, duration=0.1, volume=0.3):
    freq_end = freq_end if freq_end is not None else freq_start
    n_samples = int(SAMPLE_RATE * duration)
    path = os.path.join(os.path.dirname(__file__), filename)
    with wave.open(path, "w") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(SAMPLE_RATE)
        for i in range(n_samples):
            t = i / n_samples
            freq = freq_start + (freq_end - freq_start) * t
            fade = 1 - t
            value = int(volume * fade * 32767 * math.sin(2 * math.pi * freq * i / SAMPLE_RATE))
            wav_file.writeframesraw(struct.pack("<h", value))

if __name__ == "__main__":
    generate_tone("bounce.wav", freq_start=440, duration=0.06, volume=0.25)
    generate_tone("break.wav", freq_start=660, duration=0.08, volume=0.3)
    generate_tone("gameover.wav", freq_start=300, freq_end=100, duration=0.5, volume=0.3)
    generate_tone("win.wav", freq_start=440, freq_end=880, duration=0.5, volume=0.3)
    generate_tone("powerup.wav", freq_start=500, freq_end=700, duration=0.15, volume=0.3)
    print("Sonidos generados en assets/")
