import pygame
import random

POWERUP_TYPES = ["wide_paddle", "multi_ball", "slow_ball", "extra_life"]

COLORS = {
    "wide_paddle": (100, 150, 255),
    "multi_ball": (255, 150, 200),
    "slow_ball": (150, 255, 150),
    "extra_life": (255, 215, 0),
}

LABELS = {
    "wide_paddle": "W",
    "multi_ball": "M",
    "slow_ball": "S",
    "extra_life": "+1",
}

class PowerUp:
    def __init__(self, x, y, kind):
        self.kind = kind
        self.rect = pygame.Rect(x - 15, y - 10, 30, 20)
        self.speed = 3

    def update(self):
        self.rect.y += self.speed

    def draw(self, screen, font):
        pygame.draw.rect(screen, COLORS[self.kind], self.rect, border_radius=4)
        label = font.render(LABELS[self.kind], True, (0, 0, 0))
        screen.blit(label, label.get_rect(center=self.rect.center))


def maybe_spawn_powerup(x, y, chance=0.25):
    if random.random() < chance:
        return PowerUp(x, y, random.choice(POWERUP_TYPES))
    return None
